function sumfd = sum(fd)
%  SUM  Compute sum function for functional observations.
%  Argument:
%  FD ... a functional data object for the observations
%  Return:
%  SUMFD ... a functional data object for the sum

%  last modified 1 July 1998

  if ~isa_fd(fd)
    error ('Argument FD is not a functional data object.');
  end

  coef   = getcoef(fd);
  coefd  = size(coef);
  ndim   = length(coefd);
  nbasis = coefd(1);
  basisobj = getbasis(fd);
  if ndim == 2
    coefsum = sum(coef')';
  else
    nvar = coefd(3);
    coefsum = zeros(coefd(1),1,nvar);
    for j = 1:nvar
      coefsum(:,1,j) = sum(coef(:,:,j)')';
    end
  end
  fdnames = getnames(fd);
  fdnames{2} = 'Sum';
  fdnames{3} = ['Sum', fdnames{3}];
  sumfd = fd(coefsum, basisobj, fdnames);

