function fdParobj = putfd(fdParobj, fdobj)
%  Replace the fd parameter

fdParobj.fd = fdobj;