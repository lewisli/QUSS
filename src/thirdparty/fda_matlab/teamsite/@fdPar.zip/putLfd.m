function fdParobj = putLfd(fdParobj, Lfdobj)
%  Replace the Lfd parameter

fdParobj.Lfdobj = Lfdobj;