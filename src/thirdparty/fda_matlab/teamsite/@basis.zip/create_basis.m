function basisobj = create_basis(type, rangeval, nbasis, params)
%  CREATE_BASIS  An alternative call to CREATE_BASIS_fd.

  basisobj = basis(type, rangeval, nbasis, params);


