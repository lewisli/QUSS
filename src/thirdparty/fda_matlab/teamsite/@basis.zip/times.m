function prodbasisobj = times(basisobj1, basisobj2)
% TIMES for two basis objects sets up a basis suitable for 
%  expanding the pointwise product of two functional data
%  objects with these respective bases.  
% In the absence of a true product basis system in this code,
%  the rules followed are inevitably a compromise:
%  (1) if both bases are B-splines, the norder is the sum of the
%      two orders - 1, and the number of knots is the sum of the
%      two numbers of knots.  This is clearly a compromise that
%      will not work properly in some situations.
%  (2) if both bases are Fourier bases, AND the periods are the 
%      the same, the product is a Fourier basis with number of
%      basis functions the sum of the two numbers of basis fns.
%  (3) in all other cases, the product is a B-spline basis with
%      number of basis functions equal to the sum of the two
%      numbers.  
%  Note that in all cases where the product is a B-spline, the 
%  knots are equally spaced even if either of the two knot
%  sequences are not equally spaced.
%  Of course the intervals much also match.

%  Last modified 17 October 2003

%  check the ranges

range1 = getbasisrange(basisobj1);
range2 = getbasisrange(basisobj2);
if range1(1) ~= range2(1) | range1(2) ~= range2(2)
    error('Ranges are not equal.');
end

%  get the types

type1 = getbasistype(basisobj1);
type2 = getbasistype(basisobj2);

%  get the numbers of basis functions

nbasis1 = getnbasis(basisobj1);
nbasis2 = getnbasis(basisobj2);

if strcmp(type1, 'const') & strcmp(type2, 'const')
    %  both bases constant
    nbasis  = 1;
    prodbasisobj = create_constant_basis(range1);
    return;
end

if strcmp(type1, 'bspline') & strcmp(type2, 'bspline')
    %  both bases B-splines
    %  get orders
    interiorknots1 = getbasispar(basisobj1);
    interiorknots2 = getbasispar(basisobj2);
    norder1 = nbasis1 - length(interiorknots1);
    norder2 = nbasis2 - length(interiorknots2);
    norder  = norder1 + norder2 - 1;
    nbasis  = min(nbasis1+nbasis2, norder+1);
    prodbasisobj = create_bspline_basis(range1, nbasis, norder);
    return;
end

if strcmp(type1, 'fourier') & strcmp(type2, 'fourier')
    %  both bases Fourier
    %  check whether periods match
    period1 = getbasispar(basisobj1);
    period2 = getbasispar(basisobj2);
    if period1 == period2
        prodbasisobj = create_fourier_basis(range1, nbasis1+nbasis2, period1);
        return;
    end
end

%  default case

if strcmp(type1, 'bspline') | strcmp(type2, 'bspline')
    norder = 8;
    if strcmp(type1, 'bspline') 
        interiorknots1 = getbasispar(basisobj1);
        norder1 = nbasis1 - length(interiorknots1);
        norder = min(norder1, norder);
    end
    if strcmp(type2, 'bspline') 
        interiorknots2 = getbasispar(basisobj2);
        norder2 = nbasis2 - length(interiorknots2);
        norder = min(norder2, norder);
    end
else
    norder = min(8, nbasis1+nbasis2);
end
nbasis = max(nbasis1+nbasis2, norder+1);
prodbasisobj = create_bspline_basis(range1, nbasis, norder);