%  test fRegressFM and fRegressFFtt using weather data

%  Last modified 4 November 2003

addpath ('c:\matlab\fdaM')
addpath ('c:\matlab\fdaM\examples\weather')

%  ----------------   input the data and set up labels -------------------

fid = fopen('monthtemp.dat','rt');
tempvec = fscanf(fid,'%f');
tempmat = reshape(tempvec, [12, 35]);

fid = fopen('monthprec.dat','rt');
precvec = fscanf(fid,'%f');
precmat = reshape(precvec, [12, 35]);

meteonames =   [  'St. Johns    '; 'Charlottetown'; 'Halifax      '; ...
                  'Sydney       '; 'Yarmouth     '; 'Fredericton  '; ...
                  'Arvida       '; 'Montreal     '; 'Quebec City  '; ...
                  'Schefferville'; 'Sherbrooke   '; 'Kapuskasing  '; ...
                  'London       '; 'Ottawa       '; 'Thunder Bay  '; ...
                  'Toronto      '; 'Churchill    '; 'The Pas      '; ...
                  'Winnipeg     '; 'Prince Albert'; 'Regina       '; ...
                  'Beaverlodge  '; 'Calgary      '; 'Edmonton     '; ...
                  'Kamloops     '; 'Prince George'; 'Prince Rupert'; ...
                  'Vancouver    '; 'Victoria     '; 'Dawson       '; ...
                  'Whitehorse   '; 'Frobisher Bay'; 'Inuvik       '; ...
                  'Resolute     '; 'Yellowknife  '];

monthtime = linspace(0.5, 11.5, 12)';  %  mid points of months
weeks     = linspace(0,12,53)';        %  month values roughly in weeks

%  -------------------  set up the fourier basis object -----------------

nbasis = 12;
monthbasis = create_fourier_basis([0,12], nbasis);

%  ------------  set up the harmonic acceleration operator  -------------

Lbasis  = create_constant_basis([0,12]);  %  create a constant basis
Lcoef   = [0,(pi/6)^2,0];                 %  set up three coefficients
wfd     = fd(Lcoef,Lbasis);   % define an FD object for weight functions
wfdcell = fd2cell(wfd);       % convert the FD object to a cell object
harmaccelLfd = Lfd(3, wfdcell);  %  define the operator object

%  --------------  make temperature fd object, don't smooth  ------------

tempfd = data2fd(tempmat, monthtime, monthbasis);

tempfd_fdnames{1} = 'Months';
tempfd_fdnames{2} = 'Station';
tempfd_fdnames{3} = 'Deg C';
tempfd = putnames(tempfd, tempfd_fdnames);

%  --------------  make precipitation fd object, don't smooth  ------------

precfd = data2fd(precmat, monthtime, monthbasis);

precfd_fdnames{1} = 'Months';
precfd_fdnames{2} = 'Station';
precfd_fdnames{3} = 'mm';
precfd = putnames(precfd, precfd_fdnames);

%  -------------------------------------------------------------------
%                        Test of fRegressFFtt
%  -------------------------------------------------------------------

%  --------------  set up betafdPar  ------------

nbasis = 11;
lambda = 1e1;

betafd      = fd(zeros(nbasis,1), create_fourier_basis([0,12], nbasis));
betafdPar   = fdPar(betafd, 1, lambda, harmaccelLfd);
betacell{1} = betafdPar;

betafd      = fd(zeros(nbasis,1), create_fourier_basis([0,12], nbasis));
betafdPar   = fdPar(betafd, 1, lambda, harmaccelLfd);
betacell{2} = betafdPar;

yfdobj = precfd;

xfdcell{1} = ones(35,1);
xfdcell{2} = tempfd;

betaestcell = fRegressFFtt(yfdobj, xfdcell, betacell);

for j=1:2
    betafdj = getfd(betaestcell{j});
    plot(betafdj)
    pause
end

fd1 = xfdcell{1}.*getfd(betaestcell{1});
fd2 = xfdcell{2}.*getfd(betaestcell{2});
precfdhat = fd1 + fd2;

for i=1:35
    precvec    = eval_fd(weeks, precfd(i));
    prechatvec = eval_fd(weeks, precfdhat(i));
    plot(weeks, precvec, '-', weeks, prechatvec, '--');
    title(meteonames(i,:))
    pause
end

%  -------------------------------------------------------------------
%        Test of fRegressFFtt on monthly weather data
%  -------------------------------------------------------------------

%  indices for weather stations in each of four climate zones

atlindex = [1,2,3,4,5,6,7,8,9,10,11,13,14,16];pacindex = [25,26,27,28,29];conindex = [12,15,17,18,19,20,21,22,23,24,30,31,35];artindex = [32,33,34];
%  set up dependent variables

lambda = 1e-4;
[yfdobj, df, gcv, coef, SSE, penmat, y2cMap] = ...
       smooth_basis(monthtime, tempmat, monthbasis, ...
                    ones(12,1), harmaccelLfd, lambda);
   

%  setup design matrix.  Make it full rank and use atlantic zone
%     as baseline group

Zmat = zeros(35,4);
Zmat(:       ,1) = 1;
Zmat(pacindex,2) = 1;
Zmat(conindex,3) = 1;
Zmat(artindex,4) = 1;

%  --------------  set up betafdPar  ------------

wtvec  = ones(N,1);

nbasis = 11;
betabasis = create_fourier_basis([0,12], nbasis);
betafd = fd(zeros(nbasis,4), betabasis);

estimate  = 1;
lambda    = 1e-2;
betafdPar = fdPar(betafd, estimate, lambda, harmaccelLfd);

[betaestfdPar, D2Bmap] = fRegressFM(yfdobj, Zmat, betafdPar, wtvec);

plot(betaestfdPar)

size(D2Bmat)

y2Dmap = kron(y2cMap,eye(N));

y2Bmap = D2Bmap*y2Dmap;

Psimat = getbasismatrix(monthtime, betabasis);

B2betamap = kron(Psimat,eye(4));

y2betamap = B2betamap*y2Bmap;

