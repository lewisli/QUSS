function betaestcell = fRegressFFt(yfdobj, xfdcell, betacell, wtvec)
%  FREGRESSFFT  Fits a functional linear model using multiple 
%  functional independent variables with the dependency being 
%  pointwise or concurrent.  
%  The case of a scalar independent variable is included by treating
%  it as a functional independent variable with a constant basis
%  and a unit coefficient.
%
%  Arguments:
%  YFDOBJ   ... the dependent variable, which may
%               be either a univariate FD object or a vector
%  XFDCELL  ... a cell object of length p with each cell 
%               containing a functional data object for 
%               an independent variable.
%  BETACELL ... a cell object of length p with each cell
%               containing a functional parameter object for 
%               the corresponding regression function.
%  WTVEC    ... a vector of weights
%  
%  Returns:  
%  BETAESTCELL ... a cell object of the same length and contents
%                  as input argument BETACELL

%  Last modified 22 October 2003

%  get number of independent variables 

p = length(xfdcell);
if length(betacell) ~= p
    error(['Number of regression coefficients does not match', ...
           ' number of independent variables.']);
end

%  Get sample size and check YFDOBJ

if strcmp(class(yfdobj), 'fd')
    %  Y is functional
    ycoef = getcoef(yfdobj);
    if length(size(ycoef)) > 2
        error('YFDOBJ is not univariate.');
    end
    N = size(ycoef,2);
    ybasisobj = getbasis(yfdobj);
    rangeval  = getbasisrange(ybasisobj);
else
    if size(yfdobj,1) > 1 & size(yfdobj,2) > 1
        error('YFDOBJ is not univariate.');
    end
    %  Y is scalar or vector-valued
    warning(['YFDOBJ is not a functional data object,', ...
             ' and has been converted to one.']);
    %  convert scalar dependent variable to a 
    %  functional data object with a constant basis
    allMV = 1;
    for j=1:p
        xfdj = xfdcell{j};
        if isa_fd(xfdj)
            allMV = 0;
            rangeval = getbasisrange(getbasis(xfdj));
            break;
        end
    end
    if allMV
        error('None of the variables is functional.');
    end
    yfdobj = fd(yfdobj, onebasis);    
end
onebasis = create_constant_basis(rangeval);

%  set up some default argument values

if nargin < 4, wtvec = ones(N,1);  end

%  check weight vector

if length(wtvec) ~= N
    error('WTVEC of wrong length');
end

rangewt = [min(wtvec), max(wtvec)];

if rangewt(1) < 0
    error('WTVEC must not contain negative values.');
end

if min(wtvec) <= 0
    error('All values of WTVEC must be positive.');
end
    
%  -----------------------------------------------------------
%          set up the linear equations for the solution
%  -----------------------------------------------------------

%  compute the total number of coefficients to be estimated

ncoef = 0;
for j=1:p
    betafdParj = betacell{j};
    betafdj    = getfd(betafdParj);
    ncoefj     = size(getcoef(betafdj),1);
    ncoef      = ncoef + ncoefj;
end

Cmat = zeros(ncoef,ncoef);
Dmat = zeros(ncoef,1);

%  loop through rows of CMAT
mj2 = 0;
for j=1:p
    betafdParj = betacell{j};
    betafdj    = getfd(betafdParj);
    ncoefj     = size(getcoef(betafdj),1);
    betabasisj = getbasis(betafdj);
    xfdj       = xfdcell{j};
    if ~isa_fd(xfdj)
        if strcmp(class(xfdj), 'double')
            xfdj = fd(xfdj(:)', onebasis);
        else
            error(['Independent variable ', num2str(j), ...
                   ' is neither functional nor scalar.']);
        end
    end
    mj1 = mj2 + 1;
    mj2 = mj2 + ncoefj;
    indexj = mj1:mj2;
    %  compute right side of equation DMAT
    xywtfnj = sum(xfdj.*yfdobj);
    Dmat(indexj) = inprod_basis(betabasisj, onebasis,  0, 0, ...
                                rangeval, xywtfnj);
    %  loop through columns of CMAT
    mk2 = 0;
    for k=1:j
        betafdPark = betacell{k};
        betafdk    = getfd(betafdPark);
        ncoefk     = size(getcoef(betafdk),1);
        betabasisk = getbasis(betafdk);
        xfdk       = xfdcell{k};
        if ~isa_fd(xfdk)
            if strcmp(class(xfdk), 'double')
                xfdk = fd(xfdk(:)', onebasis);
            else
                error(['Independent variable ', num2str(k), ...
                        ' is neither functional nor scalar.']);
            end
        end
        mk1 = mk2 + 1;
        mk2 = mk2 + ncoefk;
        indexk = mk1:mk2;
        %  set up two weight functions
        xxwtfn = sum(xfdj.*xfdk);
        %  set up two weighted inner product matrices
        Cmat(indexj,indexk) = inprod_basis(betabasisj, betabasisj, 0, 0, ...
                                           rangeval, xxwtfn);
        Cmat(indexk,indexj) = Cmat(indexj,indexk);
    end
    %  attach penalty term to diagonal block
    lambda   = getlambda(betafdParj);
    if lambda > 0
        Lfdj  = getLfd(betafdParj);
        Rmatj = eval_penalty(betabasisj, Lfdj);
        Cmat(indexj,indexj) = Cmat(indexj,indexj) + lambda.*Rmatj;
    end
end

%  solve for coefficients defining BETA

betacoef = Cmat\Dmat;

%  set up fdPar object for BETAFDPAR

betaestcell = betacell;
mj2 = 0;
for j=1:p
    mj1 = mj2 + 1;
    mj2 = mj2 + ncoefj;
    indexj = mj1:mj2;
    betafdParj     = betacell{j};
    betafdj        = getfd(betafdParj);
    betaestfdj     = putcoef(betafdj, betacoef(indexj));
    betaestfdPar   = putfd(betafdParj, betaestfdj);
    betaestcell{j} = betaestfdPar;
end


