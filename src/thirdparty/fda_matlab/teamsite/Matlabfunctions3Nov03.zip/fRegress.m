function BETAESTCELL = fRegress(yfdobj, xfdcell, betacell, wtvec)
%  FREGRESS  Fits a functional linear model. 
%
%  Arguments:
%  YFDOBJ   ... the dependent variable, which may
%               be either a univariate FD object or a vector
%  XFDCELL  ... a cell object for the independent variables
%               these variables may be either functional data
%               objects or matrices.  Note that a constant
%               term, if required, must be included explicitly
%               as an independent variable consisting of a 
%               column of one's.
%  BETACELL ... a cell object for the regression functions of the
%               same length as XFDCELL.  
%               It is assumed that all regression functions are to
%               estimated.
%               If YFDOBJ is a FD, then
%                  the BETACELL{j} will be:
%                     .. a FDPAR object if XFDCELL{j} is a matrix
%                     .. either an FDPAR or a BIFDPAR object if
%                        XFDCELL{j} is a FD object.  If, in this
%                        case, XFDCELL{j} is a FD object, the
%                        pointwise or varying coefficient model
%                        is used.
%               If YFDOBJ is a vector, then
%                  the BETACELL{j} will be:
%                     .. a constant FDPAR object if XFDCELL{j} is 
%                        a matrix
%                     .. either an FDPAR object if XFDCELL{j} is 
%                        a FD object
%  WTVEC   ... a vector of weights
%  
%  Returns:  
%  BETAESTCELL ... a cell object of the same length and contents
%                  as input argument BETACELL

%  Last modified 17 October 2003

%  Get sample size and check YFDOBJ

if strcmp(class(yfdobj), 'fd')
    %  Y is functional
    ycoef = getcoef(yfdobj);
    if length(size(ycoef)) > 2
        error('YFDOBJ is not univariate.');
    end
    N = size(ycoef,2);
    ybasisobj = getbasis(yfdobj);
else
    %  Y is scalar or vector-valued
    if ~strcmp(class(yfdobj), 'double')
        error('YFDOBJ is not a matrix.');
    end
    if size(yfdobj,1) > 1 & size(yfdobj,2) > 1
        error('YFDOBJ is not a vector.');
    end
    ycoef = yfdobj(:);
    N = size(ycoef,1);
end

%  get number of independent variables 

p = length(xfdcell);

%  set up some default argument values

if nargin < 4, wtvec = ones(N,1);  end

%  check weight vector

if length(wtvec) ~= N
    error('WTVEC of wrong length');
end

rangewt = [min(wtvec), max(wtvec)];

if rangewt(1) < 0
    error('WTVEC must not contain negative values.');
end

if min(wtvec) <= 0
    error('All values of WTVEC must be positive.');
end
    
%  check each cell of XFDCELL for correct dimensions, and
%    find dimension of linear equation system

ncoef = 0;
for j=1:p
    if strcmp(class(xfdcell{j}), 'fd')
        %  X_j is functional
        xcoefj = getcoef(xfdcell{j});
        if length(size(xcoefj)) > 2
            error(['XFDCELL{',num2str(j), ...
                   '} is not univariate.']);
        end
        if N ~= size(xcoefj,2)
            error(['XFDCELL{',num2str(j), ...
                   '} is not of correct length.']);
        end
        betaparj = betacell{j};
        betafdj  = betaparj.fd;
        %  check betafdj here
        ncoefj   = size(getcoef(betafd,1),1);
    else
        %  X_j is multivariate
        if ~strcmp(class(xfdcell{j}), 'double')
            error(['XFDCELL{',num2str(j), ...
                   '} is not a matrix.']);
        end
        if size(xfdcell{j},1) ~= N
            error(['XFDCELL{',num2str(j), ...
                   '} has incorrect number of rows.']);
        end
        betaparj = betacell{j};
        betafdj  = betaparj.fd;
        %  check betafdj here
        ncoefj   = size(getcoef(betafd,1),1);
    end
    ncoef = ncoef + ncoefj;
end
 
%  -----------------------------------------------------------
%          set up the linear equations for the solution
%  -----------------------------------------------------------

Cmat = zeros(ncoef);

mj2 = 0;
for j=1:p
    betafdj   = getfd(betacell{j});
    ncoefj    = size(getcoef(betafd),1);
    basisobjj = getbasis(betafdj);
    mj1 = mj2 + 1;
    mj2 = mj2 + ncoefj;
    indexj = mj1:mj2;
    
    if strcmp(class(xfdcell{j}), 'fd')
        
        %  ----------------------------------
        %   functional independent variable
        %  ----------------------------------
        
        xfdobj = xfdcell{j};
        coefj  = getcoef(xfdobj);
        jmat   = inprod(basisobj, basisobj);
        Zmatj   = coefj * jmat;
        
    else
        
        %  ------------------------------------
        %   multivariate independent variable
        %  ------------------------------------
        
        Zmatj     = xfdcell{j};
        Jmatpsi   = inprod(basisobjj, basisobjj);
        Cmat(indexj, indexj) = Zmatj'*Zmatj*Jmatpsi;
        lambda = getlambda(betacell{j});
        if lambda > 0
            Jmatphipsi = inprod(ybasisobj, xbasisobj);
            Cmat(indexj,indexj) = Cmat(indexj,indexj) + Jmaxphipsi';
                
    end
    
    Zmat = [Zmat, Zmatj];
        
end


Cmat = Zmat'*Zmat;


