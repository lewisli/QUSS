%  -------------------------------------------------------------------
%        Test of fRegressFM on daily weather data
%  -------------------------------------------------------------------

fid = fopen('dailtemp.dat','rt');
tempav = fscanf(fid,'%f');
tempav = reshape(tempav, [365,35]);

fid = fopen('dailprec.dat','rt');
precav = fscanf(fid,'%f');
precav = reshape(precav, [365,35]);

daytime = (1:365)-0.5;

N = 35;

place = [ ...
'arvida  '; 'bagottvi'; 'calgary '; 'charlott'; 'churchil'; 'dawson  '; ...
'edmonton'; 'frederic'; 'halifax '; 'inuvik  '; 'iqaluit '; 'kamloops'; ...
'london  '; 'montreal'; 'ottawa  '; 'princeal'; 'princege'; 'princeru'; ...
'quebec  '; 'regina  '; 'resolute'; 'scheffer'; 'sherbroo'; 'stjohns '; ...
'sydney  '; 'thepas  '; 'thunderb'; 'toronto '; 'uraniumc'; 'vancouvr'; ...
'victoria'; 'whitehor'; 'winnipeg'; 'yarmouth'; 'yellowkn'];

%  -------------  set up fourier basis  ---------------------------
%  Here it was decided that 65 basis functions captured enough of
%  the detail in the temperature data: about one basis function
%  per week.  However, see below for smoothing with a saturated
%  basis (365 basis functions) where smoothing is defined by the
%  GCV criterion.

Lbasis  = create_constant_basis([0,365]);  %  create a constant basis
Lcoef   = [0,(2*pi/365)^2,0];    %  set up three coefficients
wfd     = fd(Lcoef,Lbasis);      % define an FD object for weight functions
wfdcell = fd2cell(wfd);          % convert the FD object to a cell object
harmaccelLfd = Lfd(3, wfdcell);  %  define the operator object

nbasis   = 11;
daybasis = create_fourier_basis([0,365], nbasis);

lambda = 1e-4;
[yfdobj, df, gcv, coef, SSE, penmat, y2cMap] = ...
       smooth_basis(daytime, tempav, daybasis, ...
                    ones(365,1), harmaccelLfd, lambda);

ymat = eval_fd(daytime, yfdobj);

rmat = tempav - ymat;

variance = sum(rmat.^2,2)./N;

atlindex = [1,2,4,8,9,13,14,15,19,22,23,24,25,28,34];
pacindex = [12,17,18,30,31];
conindex = [3,5,6,7,16,20,26,27,29,32,33,35];
artindex = [10,11,21];

Zmat = zeros(35,4);
Zmat(:       ,1) = 1;
Zmat(pacindex,2) = 1;
Zmat(conindex,3) = 1;
Zmat(artindex,4) = 1;

wtvec  = ones(N,1);

nbasis = 11;
betabasis = create_fourier_basis([0,365], nbasis);
betafd = fd(zeros(nbasis,4), betabasis);

estimate  = 1;
lambda    = 1e-4;
betafdPar = fdPar(betafd, estimate, lambda, harmaccelLfd);

[betaestfdPar, D2Bmap] = fRegressFM(yfdobj, Zmat, betafdPar, wtvec);

plot(betaestfdPar)

size(D2Bmat)

y2Dmap = kron(y2cMap,eye(N));

betamat = eval_fd(daytime, getfd(betaestfdPar));

yhatmat = Zmat*betamat';
rmat = tempav - yhatmat';

variance = sum(rmat.^2,2)./N;

y2Bmap = D2Bmap*y2Dmap;

weeks = linspace(0,365,53)';   %  day values roughly in weeks

Psimat = getbasismatrix(weeks, betabasis);

B2betamap = kron(Psimat,eye(4));

y2betamap = B2betamap*y2Bmap;

temp = kron(variance,ones(N,1));

Varbeta = (y2betamap.*(ones(212,1)*temp'))*y2betamap';

Varbetamat = reshape(diag(Varbeta),4,53);

plot(weeks,Varbetamat')

betamat = eval_fd(weeks, getfd(betaestfdPar));

for j=1:4
    plot(weeks, betamat(:,j), '-', ...
         weeks, betamat(:,j) + 2.*sqrt(Varbetamat(j,:))', 'g--', ...
         weeks, betamat(:,j) - 2.*sqrt(Varbetamat(j,:))', 'g--')
    title(['Regression function ',num2str(j)])
    pause;
end

%  an alternative calculation that keeps matrices small

Jmatpsipsi = inprod_basis(betabasis,betabasis);
Jmatphipsi = inprod_basis(daybasis,betabasis);
Jmatphiphi = inprod_basis(daybasis,daybasis);
Rmat       = eval_penalty(betabasis,harmaccelLfd);

temp1 = Jmatphipsi'*y2cMap;
fac1  = temp1*diag(variance)*temp1';
temp2 = kron(fac1, Zmat'*Zmat);
fac2  = inv(kron(Jmatpsipsi,Zmat'*Zmat) + ...
            kron(lambda.*Rmat,eye(4)));
Varbeta2 = B2betamap*fac2*temp2*fac2'*B2betamap';
Varbetamat2 = reshape(diag(Varbeta2),4,53);
plot(weeks,Varbetamat2')
