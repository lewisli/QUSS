function [betaestfdPar, D2Bmap] = fRegressFM(yfdobj, Zmat, ...
                                             betafdPar, wtvec)
%  FREGRESSFM  Fits a functional linear model for a functional
%    dependent variable and a multivariate independent variable. 
%
%  Arguments:
%  YFDOBJ    ... the dependent variable, which is a univariate 
%                FD object
%  ZMAT      ... a design matrix  Note that a constant
%                term, if required, must be included explicitly
%                as an independent variable consisting of a 
%                column of one's.
%  BETAFDPAR ... a functional parameter object for 
%                the regression function(s).
%                It is assumed that all regression functions are to
%                estimated.
%                This version of the program does not all 
%                different smoothing parameters for the 
%                regression functions.
%  WTVEC     ... a vector of weights
%  
%  Returns:  
%  BETAESTFDPAR ... a functional parameter object for 
%                the regression function(s).

%  Last modified 5 November 2003

%  Get sample size and check YFDOBJ

if strcmp(class(yfdobj), 'fd')
    %  Y is functional
    ycoef = getcoef(yfdobj);
    if length(size(ycoef)) > 2
        error('YFDOBJ is not univariate.');
    end
    N = size(ycoef,2);
    ybasisobj = getbasis(yfdobj);
else
    if ~strcmp(class(yfdobj), 'double')
        error('YFDOBJ is not a functional data object.');
    end
end

%  get number of independent variables 

p = size(Zmat,2);

%  set up some default argument values

if nargin < 4, wtvec = ones(N,1);  end

%  check weight vector

if length(wtvec) ~= N
    error('WTVEC of wrong length');
end

rangewt = [min(wtvec), max(wtvec)];

if rangewt(1) < 0
    error('WTVEC must not contain negative values.');
end

if min(wtvec) <= 0
    error('All values of WTVEC must be positive.');
end

%  -----------------------------------------------------------
%          set up the linear equations for the solution
%  -----------------------------------------------------------

betafd       = getfd(betafdPar);
betancoef    = size(getcoef(betafd),1);
betabasisobj = getbasis(betafd);
Jmatpsipsi   = eval_penalty(betabasisobj, 0);
WmatZmat     = (wtvec*ones(1,p)).*Zmat;
ZtWZmat      = Zmat'*WmatZmat;
Cmat         = kron(Jmatpsipsi,ZtWZmat);
lambda       = getlambda(betafdPar);
if lambda > 0
    Lfdobj = getLfd(betafdPar);
    Rmat   = eval_penalty(betabasisobj, Lfdobj);
    Cmat   = Cmat + lambda.*kron(Rmat, eye(p));
end
Jmatphipsi = inprod_basis(ybasisobj,betabasisobj);
Dmat = reshape(WmatZmat'*ycoef'*Jmatphipsi,p*betancoef,1);

%  solve for coefficients defining BETA

Cmatinv     = inv(Cmat);
betacoefvec = Cmatinv*Dmat;
betacoef    = reshape(betacoefvec, p, betancoef)';

%  set up fdPar object for BETAFDPAR

betafd       = putcoef(betafd, betacoef);
betaestfdPar = putfd(betafdPar, betafd);

%  Compute mapping matrix for the mapping from coefficients 
%  for the dependent variable to the coefficients for 
%  the regression functions

D2Bmap = Cmatinv*kron(Jmatphipsi,WmatZmat)';



