function Dy = oscillate(t, y, Amat)
  Dy = Amat*y;