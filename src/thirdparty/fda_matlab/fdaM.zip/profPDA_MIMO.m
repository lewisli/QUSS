function [PENSSE, PEN, DSSE, coefcell, fitcell, ...
        penmatcell, Dpenmatcell] = ...
                          profPDA_MIMO(bvec, fitcell, gradwrd)
                      
% profPDAm estimates a system of M homogeneous linear 
%  differential equations directly from discrete noisy 
%  observations of a process.  
%  In this version forcing functions can be accommodated. 
%
%profPDAm works with the basis function expansions of the
%  estimates of the coefficient functions a_k(t) and b_j(t) 
%  in the possibly nonhomogeneous linear differential operator
%
%   L_i x_i(t) =  
%     b_{i01}(t) x_1(t) + ... + b_{i,m-1,1}(t) D^{m-1}x_1(t) +
%                          .
%                          .
%                          .
%     b_{iM1}(t) x_M(t) + ... + b_{i,m-1,M}(t) D^{m-1}x_M(t) + 
%     D^m x_i(t) - a_{1i}(t)u_1(t) - ... - a_{k_i,i}(t)u_K(t) 
%
%  that minimizes the least squares fitting criterion
%
%   \sum\i \{ \sigma_i^{-2} \| [y - x(t)] \|^2 + 
%             \lambda_i     \| L_i x_i    \|^2 \}
%
%  Arguments:
%  BVEC       ... A super-vector containing vectors of coefficients defining 
%                 the weight functions to be estimated.  
%                 Coefficients are stacked on top of each other as follows:
%                 coefficients for b_0 first, b_1 next, and so on, and
%                 then continues on to the forcing function coefficients
%                 to be estimated.  See BVEC2LFD for more details.
%  FITCELL    ... Cell array with one cell per variable.
%                 The contents of each cell are a struct containing:
%    Y        ... N by NCURVES matrix of curve values to be fit for this
%                 variable.  N and NCURVES can vary from one variable to
%                 another.
%    BASISOBJ ... A basis object for representing the curve(s)
%                   that are the solutions of the differential equations
%                   that fit the data
%    BASISMAT ... Matrix of basis function values at sampling points.
%    BMAT     ... Weighted cross-product matrix for basis matrix values.
%    DMAT     ... Weighted product of transposed basis matrix and Y.
%    LAMBDA   ... The smoothing parameter controlling the penalty on
%                   the roughness penalty.  In order to estimate the 
%                   DIFE, this should be large but not too large.  
%                   If it is too small, the roughness is ignored, and
%                   the differential equation is badly estimated.
%                   If it is too large, though, the data are ignored and
%                   the DIFE is also badly estimated.  
%    DDORDER  ... Order of the differential equation.
%    BWTCELL  ... Cell array of dimensions M and m for the weight functions  
%                   for the homogeneous part of the equation.  
%    AWTCELL  ... Cell array for the weight functions for the 
%                   forcing functions
%    UFDCELL  ... Cell array containing functional data objects for
%                   the forcing functions
%  Returns:
%  SSE     ...  The error sum of squares.  This is what is
%               required for numerical optimization software since it
%               is the objective function being minimized.
%  DSSE    ...  The gradient of SSE.  Computed only if DERIVS is nonzero,
%               otherwise is returned as an empty matrix.
%  PENSSE  ...  The penalized error sum of squares.  
%               It is PENSSE = SSE + lambda.*C'KC, where C is the 
%               coefficient vector or matrix defining the curve(s) 
%               fitting the data and K is the penalty matrix corresponding
%               to the estimated DIFE.                 
%  FDOBJ   ...  Functional data object fitting the data
%  DF      ...  A measure of the equivalent degrees of freedom in the
%               smoothing matrix.
%  GCV     ...  The generalized cross-validation criterion

%  Last modified 19 July 2004

if nargin < 3,  gradwrd = 0;  end

%  check number of variables

nvar = length(fitcell);

nbasisvec = zeros(nvar,1);

%  -------------------------------------------------------------------
%       check contents of each cell for cell array FITCELL.
%  -------------------------------------------------------------------

N = 0;
for ivar = 1:nvar
    
    fitstruct = fitcell{ivar};

    %  check Y

    [n, ncurves] = size(fitstruct.y);
    if n == 1 & ncurves > 1
        %  transpose Y is n == 1
        y = y';
        fitstruct.y = y;
        fitcell{ivar} = fitstruct;
        temp    = n;
        n       = ncurves;
        ncurves = temp;
    end
    N = N + n;
        
    %  check BASISOBJ
    
    basisobj  = fitstruct.basisobj;
    
    if ~isa_basis(fitstruct.basisobj)
        error(['BASISOBJ is not a basis object for FITCELL{', ...
                num2str(ivar), '}.']);
    end
    
    nbasis = getnbasis(basisobj);
    nbasisvec(ivar) = nbasis;
    
    %  check LAMBDA
    
    lambda = fitstruct.lambda;
    if lambda < 0
        warning ('Value of LAMBDA was negative, and 0 used instead.');
        fitstruct.lambda = 0;
        fitcell{ivar} = fitstruct;
    end
    
    %  check DORDER
    
    Dorderi = fitstruct.Dorder;
    if ivar == 1
        Dorder = Dorderi;
        if Dorder < 1
            error('Order of differential equation less than one.');
        end
    else
        if Dorder ~= Dorderi
            error('DORDER is not the same for all variables.');
        end
    end
        
    %  check BWTCELL
    
    bwtcell = fitstruct.bwtcell;  
    
    if size(bwtcell,1) ~= nvar
        error(['First dimension of BWTCELL is not of length NVAR for FITCELL{', ...
                num2str(ivar), '}.']);
    end
    if size(bwtcell,2) ~= Dorder
        error('Second dimension of BWTCELL is not equal to DORDER.');
    end
    
    %  check AWTCELL and UFDCELL
    
    awtcell = fitstruct.awtcell;   
    if isempty(awtcell) & isempty(fitstruct.ufdcell)
        nforce = 0;
    else
        nforce = length(awtcell);
        if length(fitstruct.ufdcell) ~= nforce
            error(['AWTCELL and UFDCELL are not of same length for FITCELL{', ...
                num2str(ivar), '}.']);
        end
    end
    
    %  check Bmat and Dmat
    
    Bmat    = fitstruct.Bmat;
    if size(Bmat,1) ~= nbasis | size(Bmat,2) ~= nbasis
        error(['BMAT has incorrect dimension(s) for FITCELL{', ...
                num2str(ivar), '}.']);
    end
    
    Dmat    = fitstruct.Dmat;
    if size(Dmat,1) ~= nbasis
        error(['DMAT has incorrect first dimension for FITCELL{', ...
                num2str(ivar), '}.']);
    end
    
end

ncoefs = sum(nbasisvec);
    
%  -------------------------------------------------------------------
%       transfer parameters from vector BVEC to cell arrays
%                        BWTCELL and AWTCELL
%  -------------------------------------------------------------------

[fitcell, npar] = bvec2fitcell(bvec, fitcell);

%  -------------------------------------------------------------------
%         Compute the penalty matrices and penalty vectors
%  -------------------------------------------------------------------

[penmatcell, Dpenmatcell] = eval_Rsm(npar, fitcell, gradwrd);

%  -------------------------------------------------------------------
%          Define left and right sides of linear equation defining 
%                  the coefficient vector
%  -------------------------------------------------------------------

%  set up matrices for the linear equation

Cmat = zeros(ncoefs,ncoefs);
Pmat = zeros(ncoefs,ncoefs);
Dmat = zeros(ncoefs,1);

%  fill the matrices

mi2 = 0;
for ivar=1:nvar
    mi1       = mi2 + 1;
    mi2       = mi2 + nbasisvec(ivar);
    indi      = mi1:mi2;
    
    %  extract data matrices
    
    fitstruct = fitcell{ivar};
    Bmati     = fitstruct.Bmat;
    Dmati     = fitstruct.Dmat;
    lambdai   = fitstruct.lambda;
    
    %  extract penalty matrices
    
    penstruct = penmatcell{ivar};
    Rmati     = penstruct.Rmat;
    Smati     = penstruct.Smat;
    Tmati     = penstruct.Tmat;
    Umati     = penstruct.Umat;
    Vmati     = penstruct.Vmat;
    
    if isempty(fitstruct.awtcell) | ...
       isempty(fitstruct.ufdcell)
        nforce = 0;
    else
        nforce = length(awtcell);
    end
    
    %  set up diagonal block with coefficient matrix BMAT 
    %  plus lambda*R
    
    Cmat(indi,indi) = Bmati;
    Pmat(indi,indi) = Pmat(indi,indi) + lambdai.*Rmati;
    
    %  update all blocks of Cmat with the Smat matices
    
    Pmat = Pmat + lambdai.*Smati;
    
    %  update off-diagonal blocks of coefficient matrix 
    %  for rows or columns in block IVAR
    
    lamTmati = lambdai.*Tmati;
    Pmat(indi,:) = Pmat(indi,:) + lamTmati;
    Pmat(:,indi) = Pmat(:,indi) + lamTmati';
    
    %  set up right side vector DMAT
    
    Dmat(indi) = Dmat(indi) + Dmati;
    if nforce > 0
        Dmat(indi) = Dmat(indi) + lambdai.*Umati; 
        Dmat       = Dmat + lambdai.*Vmati;
    end
    
end

%  -------------------------------------------------------------------
%                    Solve the linear system
%  -------------------------------------------------------------------

%  compute inverse of Cmat

Cmatinv = inv(Cmat + Pmat);

%  solve normal equations for each observation

coef = Cmatinv * Dmat;

%  -------------------------------------------------------------------
%                 Compute error sum of squares
%  -------------------------------------------------------------------

SSE = 0;
m2  = 0;
res = [];
for ivar=1:nvar
    m1 = m2 + 1;
    m2 = m2 + nbasisvec(ivar);
    indi = m1:m2;
    coefi = coef(indi);
    coefcell{ivar} = coefi;
    
    %  compute error sum of squares
    
    fitstruct = fitcell{ivar};
    basismati = fitstruct.basismat;
    yi        = fitstruct.y;
    yhati     = basismati * coefi;
    resi      = yi - yhati;
    res       = [res; resi];
    SSEi      = sum(sum(resi.^2));
    SSE       = SSE + SSEi;
end

%  compute penalty term

PEN = coef' * Pmat * coef;

%  -------------------------------------------------------------------
%       Update the error sum of squares 
%     for any roughness penalties on parameters
%  -------------------------------------------------------------------

PENSSE = SSE;
% 
% for ivar = 1:nvar
%     
%     fitstruct = fitcell{ivar};    
%     bwtcell   = fitstruct.bwtcell;   
%     awtcell   = fitstruct.awtcell;   
% 
%     if isempty(awtcell) | isempty(fitstruct.ufdcell)
%         nforce = 0;
%     else
%         nforce = length(awtcell);
%     end
% 
%     for jvar=1:nvar
%         bfdParj = bwtcell{jvar};
%         if getestimate(bfdParj)
%             lambdaj = getlambda(bfdParj);
%             if lambdaj > 0
%                 bfdobjj = getfd(bfdParj);
%                 bcoefj  = getcoef(bfdParj);
%                 bbasisj = getbasis(bfdobjj);
%                 Lfdobjj = getLfd(bfdParj);
%                 bRmatj  = eval_penalty(bbasisj, Lfdobjj);
%                 PENSSE  = PENSSE + lambdaj.*bcoefj'*bRmatj*bcoefj;
%             end
%         end
%     end
%     
%     %  loop through forcing functions to transfer coefficients from
%     %  BVEC to the appropriate forcing function weight functions
%     
%     for k=1:nforce
%         afdPark = awtcell{k};
%         if getestimate(afdPark)
%             lambdak  = getlambda(afdPark);
%             if lambdak > 0
%                 afdobjk = getfd(afdPark);
%                 acoefk  = getcoef(afdPark);
%                 abasisk = getbasis(afdobjk);
%                 aLfdk   = getLfd(afdPark);
%                 aRmatk  = eval_penalty(abasisk, aLfdk);
%                 PENSSE  = PENSSE + lambdak.*acoefk'*aRmatk*acoefk;
%             end
%         end
%     end
%     
% end

%  --------------------------------------------------------------
%                       Compute gradient
%  --------------------------------------------------------------

if gradwrd
    
    %  set up supermatrix containing submatrices of basis function
    %  values on the diagonal blocks
    
    Phimat = zeros(N,ncoefs);
    mi2 = 0;
    Ni2 = 0;
    for ivar=1:nvar
        mi1 = mi2 + 1;
        mi2 = mi2 + nbasisvec(ivar);
        fitstruct = fitcell{ivar};
        basismat  = fitstruct.basismat;
        Ni        = length(fitstruct.y);
        Ni1 = Ni2 + 1;
        Ni2 = Ni2 + Ni;
        Phimat(Ni1:Ni2,mi1:mi2) = basismat;
    end
    
    %  multiply by the inverse of the coefficient supermatrix
    
    PhiCmatinv = Phimat*Cmatinv;
    
    %  the outer two loops go through parameters to be estimated
    
    %  loop through the equations
    
    mi2  = 0;
    mpar = 0;
    m2   = 0;
    for ivar=1:nvar
        mi1  = mi2 + 1;
        mi2  = mi2 + nbasisvec(ivar);
        indi = mi1:mi2;
        fitstruct  = fitcell{ivar};
        awtcell    = fitstruct.awtcell;
        bwtcell    = fitstruct.bwtcell;
        lambdai    = fitstruct.lambda;
        %  retrieve the derivatives of penalty matrices
        Dpenstruct = Dpenmatcell{ivar}; 
        DSmat      = Dpenstruct.DSmat;
        DTmat      = Dpenstruct.DTmat;
        DUmat      = Dpenstruct.DUmat;
        DaVmat     = Dpenstruct.DaVmat;
        DbVmat     = Dpenstruct.DbVmat;
        
        %  loop through variables J inside this equation I to
        %  compute derivatives with respect to weight functions
        %  variables
        
        mj2  = 0;
        nbpar = 0;
        for jvar = 1:nvar
            bfdParj = bwtcell{jvar};
            mj1  = mj2 + 1;
            mj2  = mj2 + nbasisvec(jvar);
            indj = mj1:mj2;
            if getestimate(bfdParj) 
                bfdobjj = getfd(bfdParj);
                bbasisj = getbasis(bfdobjj);
                bnbasis = getnbasis(bbasisj);
                %  
                m1 = m2 + 1;
                m2 = m2 + bnbasis;
                for m = m1:m2
                    nbpar = nbpar + 1;
                    %  set up derivative supermatrix for this
                    %  parameter
                    DCmat  = zeros(ncoefs,ncoefs);
                    %  update the supermatrix for DSmat
                    DCmat = DCmat + lambdai.*DSmat(:,:,nbpar);
                    %  update the supermatrix for DTmat
                    temp = lambdai.*DTmat(:,:,nbpar);
                    DCmat(indi,:) = DCmat(indi,:) + temp;
                    DCmat(:,indi) = DCmat(:,indi) + temp';
                    %  compute the derivative of the smoothing matrix
                    if nforce > 0
                        %  forcing functions present:
                        DDmatm = zeros(ncoefs,1);
                        DDmatm(indj) = DDmatm(indj) + ...
                                lambdai.*DbVmat(indj,nbpar);
                        DAmatm = PhiCmatinv* ...
                                 (-DCmat*coef + DDmatm*ones(1,ncurves));
                    else
                        %  no forcing functions
                        DAmatm = -PhiCmatinv*DCmat*coef;
                    end
                    mpar  = mpar  + 1;
                    DSSE(mpar) = -2.*trace(res'*DAmatm);
                end
            end
        end
        
        %  loop through forcing functions to compute derivatives
        %  with respect to forcing function coefficients
        
        napar = 0;
        for k=1:nforce
            afdPark = awtcell{k};
            if getestimate(afdPark) 
                abasisk  = getbasis(getfd(afdPark));
                nbasisk = getnbasis(abasisk);
                m1 = m2 + 1;
                m2 = m2 + nbasisk;
                for m = m1:m2
                    napar = napar + 1;
                    %  compute derivative or right side for
                    %  this parameter
                    DDmatm = zeros(ncoefs,1);
                    DDmatm(indi) = lambdai.*DUmat(:,napar);
                    DDmatm = DDmatm + lambdai.*DaVmat(:,napar);
                    DAmatm  = PhiCmatinv*DDmatm;
                    mpar = mpar  + 1;
                    DSSE(mpar) = -2.*sum(res'*DAmatm);
                end
            end
        end
    end
%  -------------------------------------------------------------------
%       Update the error sum of squares 
%     for any roughness penalties on parameters
%  -------------------------------------------------------------------

DPENSSE = DSSE;

m2 = 0;
for ivar = 1:nvar
    
    fitstruct = fitcell{ivar};    
    bwtcell   = fitstruct.bwtcell;   
    awtcell   = fitstruct.awtcell;   

    if isempty(awtcell) | isempty(fitstruct.ufdcell)
        nforce = 0;
    else
        nforce = length(awtcell);
    end

    for jvar=1:nvar
        bfdParj = bwtcell{jvar};
        if getestimate(bfdParj)
            lambdaj = getlambda(bfdParj);
            bfdobjj = getfd(bfdParj);
            bbasisj = getbasis(bfdobjj);
            bnbasis = getnbasis(bbasisj);
            m1      = m2 + 1;
            m2      = m2 + bnbasis;
            indm    = m1:m2;
            if lambdaj > 0
                bcoefj = getcoef(bfdParj);
                bLfdj  = getLfd(bfdParj);
                bRmatj = eval_penalty(bbasisj, bLfdj);
                DPENSSE(indm) = DPENSSE(indm) + ...
                                2*lambdaj.*bRmatj*bcoefj;
            end
        end
    end
    
    %  loop through forcing functions to transfer coefficients from
    %  BVEC to the appropriate forcing function weight functions
    
    for k=1:nforce
        afdPark = awtcell{k};
        if getestimate(afdPark)
            lambdak = getlambda(afdPark);
            afdobjk = getfd(afdPark);
            abasisk = getbasis(afdobjk);
            anbasis = getnbasis(abasisk);
            m1      = m2 + 1;
            m2      = m2 + anbasis;
            indm    = m1:m2;
            if lambdak > 0
                acoefk = getcoef(afdPark);
                aLfdk  = getLfd(afdPark);
                aRmatk = eval_penalty(abasisk, aLfdk);
                DPENSSE(indm) = DPENSSE(indm) + ...
                                2*lambdak.*aRmatk*acoefk;
            end
        end
    end
    
end

else
    DSSE = [];
end

%  -------------------------------------------------------------------

