fdMatobj = fdMat(0);

class(fdMatobj)

getmat(fdMatobj)

fdMatobj = putmat(fdMatobj,[1,2;3,4])

