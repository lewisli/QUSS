function isaLfd = isa_Lfd(Lfdobj)
%  ISA_LFD  checks argument is either integer or functional data object.

%  last modified 8 August 2003

isaLfd = 0;
if strcmp(class(Lfdobj), 'lfd') | strcmp(class(Lfdobj), 'Lfd')
    isaLfd = 1;
end

