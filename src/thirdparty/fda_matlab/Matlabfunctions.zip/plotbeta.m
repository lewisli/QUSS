function plotbeta(betaestcell, betastderrcell, argvals)
rangeval = getbasisrange(getbasis(getfd(betaestcell{1})));
if nargin < 3
    argvals = linspace(rangeval(1),rangeval(2),51)';
end
n = length(argvals);
p = length(betaestcell);
for j=1:p
    betavec    = eval_fd(argvals, getfd(betaestcell{j}));
    plot(argvals, betavec, '-')
    line([rangeval(1),rangeval(2)],[0,0],'LineStyle',':','Color','r')
    if nargin > 1
        betastderr = eval_fd(argvals, betastderrcell{j});
        betavecp = betavec + 2.*betastderr;
        betavecm = betavec - 2.*betastderr;
        fill([argvals;   argvals(n:-1:1)], ...
            [betavecp;   betavecm(n:-1:1)], 'w', 'LineStyle', '--')
        line(argvals, betavec,'Color','b','LineWidth',2)
        line([rangeval(1),rangeval(2)],[0,0],'LineStyle',':','Color','r')
        for i=1:n
            line([argvals(i),argvals(i)],[betavecm(i),betavecp(i)])
        end
    end
    title(['\fontsize{16} Regression function ',num2str(j)])
    v = axis;
    axis([rangeval(1),rangeval(2),v(3),v(4)])
    pause
end
